/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;
import java.awt.*;
import java.awt.event.KeyEvent;
public class InstructionsState extends GameStateTemplate{
    private String[] options = {"Player 1 - WASD to Move, Q to place Bomb.", "Player 2 - IJKL to Move, U to place Bomb.", "Backspace - Return to Menu"};

    public InstructionsState(GameStateManager gsm){
        super(gsm);
    }

    public void init(){

    }

    public void tick(){

    }

    public void draw(Graphics g){
        g.setFont(new Font("Arial", Font.PLAIN, 35));
        for(int i = 0; i < options.length; i++){
            g.setColor(Color.BLACK);
            g.drawString(options[i], GameWindow.WIDTH / 2 - 370, 200 + i * 70);
        }
    }

    public void keyPressed(int k){
        if(k == KeyEvent.VK_BACK_SPACE){
            gsm.states.pop();
        }
    }

    public void keyReleased(int k){

    }
}
