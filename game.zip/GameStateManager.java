package game;

import java.awt.*;
import java.util.*;

/*
Contains a stack of game states as some form of ghetto polymorphism
the functions tick, draw, keyPressed, keyReleased depend on the game state
*/

public class GameStateManager {

    public Stack<GameStateTemplate> states;

    public GameStateManager(){
        states = new Stack<GameStateTemplate>();
        states.push(new MenuState(this));
    }

    public void tick(){
        states.peek().tick();
    }

    public void draw(Graphics g){
        states.peek().draw(g);
    }

    public void keyPressed(int k){
        states.peek().keyPressed(k);
    }

    public void keyReleased(int k){
        states.peek().keyReleased(k);
    }
}